<footer>
		<img class="imgf" src="images/ralogo_monogram.PNG">
		<p class="pf">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
		tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
		quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
		consequat.</p>
		<nav class="navf">
			<ul>
				<li class="f3"><a class="f2"  href="">About the Roux |</a></li>
				<li class="f3"><a class="f2" href="">Privacy Policy |</a></li>
				<li class="f3"><a class="f2" href="">Visit Our Wibsite |</a></li>
			</ul>
		</nav>
	</footer>