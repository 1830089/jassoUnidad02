<article>
			<h2 class="rojo">Coming to the event?</h2>
			<h3 class="gris">Check out our mobile site</h3>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
			tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
			quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
			consequat.</p>
			<img width="80%" src="images/iphone.PNG">
            <a class="egris" href="">Roux Mobile</a>
            <br>
</article>
       
