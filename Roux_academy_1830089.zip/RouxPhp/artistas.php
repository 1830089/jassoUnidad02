<section>
			<h2>Featured Artists</h2>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
			tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
			quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
			consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
			cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
			proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
		</section>
		<br>
         <img src="images/artists/Barot_Bellingham_tn.jpg">
            <img src="images/artists/Constance_Smith_tn.jpg">
            <img src="images/artists/Hassum_Harrod_tn.jpg"> <br>
            <img src="images/artists/Hillary_Goldwynn_tn.jpg">
            <img src="images/artists/Jennifer_Jerome_tn.jpg">
            <img src="images/artists/Jonathan_Ferrar_tn.jpg"><br>
            <img src="images/artists/LaVonne_LaRue_tn.jpg">
            <img src="images/artists/Riley_Rewington_tn.jpg">
            <img src="images/artists/Xhou_Ta_tn.jpg">
            <p class="egris"><a class="egris" href="art.html">View Artist Info</a></p>
            <br>
        <section >