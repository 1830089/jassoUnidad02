<section class="aside-A">
						<h2>Fatured Artists</h2>
						
						<p>
							Each year, nine individuals are honored as Featured Artists - each being granted his or her own exhibit hall to display entire collections or themed pieces. Each Featured Artist has an opportunity to speak at the conference to share his or her vision, perspective, and techniques with conference attendees.
						</p>
						<div class="collage-A">
							<img src="./img/artists/Barot_Bellingham_tn.jpg" >
							<img src="./img/artists/Constance_Smith_tn.jpg" >
							<img src="./img/artists/Hassum_Harrod_tn.jpg" >
							<img src="./img/artists/Hillary_Goldwynn_tn.jpg" >
							<img src="./img/artists/Jennifer_Jerome_tn.jpg" >
							<img src="./img/artists/Jonathan_Ferrar_tn.jpg" >
							<img src="./img/artists/LaVonne_LaRue_tn.jpg" >
							<img src="./img/artists/Riley_Rewington_tn.jpg" >
							<img src="./img/artists/Xhou_Ta_tn.jpg">
						</div>
						
						<?php require 'check_out.php';?>
					</section>