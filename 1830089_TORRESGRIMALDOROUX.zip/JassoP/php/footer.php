<footer>
					<div class="Flogo">
					<img src="img/ralogo_monogram.png" class="Fimg" >
					<p>Join over 500 hundred of the most creative and brilliant minds of art colleges all around the world for three days of lectures by world-renowned art scholars and artists.</p>
					</div>
					<div class ="footer">
						<ul>
							<li> <a href="about.html">About the Roux Academy</a></li>
							<li>|</li>
							<li> <a href="privacy.html">Privacy Policy</a></li>
							<li>|</li>
							<li> <a href="index.html">Visit our website</a></li>
						</ul>
					</div>
			</footer>