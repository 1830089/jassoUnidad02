<h3 class="t-rojo">Coming to the event</h3>
<h4 class= "t-gris">Check out our mobile site</h4>
<p>
	Our mobile site contains schedules, and exhibit/ artist details, accessible simply by scanning QR codes located all around the venue exhibit halls.
</p>
<img src="img/iphone.png" class= "iphone">
<a href="index.html" class="a_artist"> Roux Mobile >></a>